"""Core module for phoenix."""

