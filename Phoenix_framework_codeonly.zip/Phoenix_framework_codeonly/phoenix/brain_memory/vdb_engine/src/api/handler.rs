use axum::{extract::State, Json, http::StatusCode};
use crate::api::models::*;
use crate::api::routers::AppState; 
use crate::domain::entities::{EngineTrait, CollectionTrait, };

pub async fn create_collection_handler(
    State(state): State<AppState>, 
    Json(payload): Json<CreateCollectionRequest>,
) -> Result<Json<DefaultSuccessCreationResponse>, (StatusCode, String)> {
    
    // 1. We want to CREATE a collection, so we need a WRITE lock!
    // This will pause if someone else is currently writing.
    let mut engine = state.engine.write().unwrap();

    // 2. Do the database work
    let index_type_str = payload.index_type.as_deref();
    
    match engine.create_collection(&payload.collection_name, index_type_str) {
        Ok(_) => {
            Ok(Json(DefaultSuccessCreationResponse {
                success: true,
                message: format!("Collection {} created successfully", payload.collection_name),
            }))
        },
        Err(e) => Err((StatusCode::BAD_REQUEST, e.to_string())), 
    }
}

pub async fn get_collection_handler(
    State(state): State<AppState>, 
    Json(payload): Json<GetCollectionRequest>,
) -> Result<Json<DefaultSuccessCreationResponse>, (StatusCode, String)> {
    
    // 1. We want to CREATE a collection, so we need a WRITE lock!
    // This will pause if someone else is currently writing.
    let engine = state.engine.write().unwrap();
    
    match engine.get_collection(&payload.collection_name) {
        Ok(_collection) => {  
            Ok(Json(DefaultSuccessCreationResponse {
                success: true,
                message: format!("Collection {} retrieved successfully", payload.collection_name),
            }))
        },
        Err(e) => Err((StatusCode::BAD_REQUEST, e.to_string())), 
    }
}



pub async fn insert_record_handler(
    State(state): State<AppState>,
    Json(payload): Json<InsertRecordRequest>, 
) -> Result<Json<DefaultSuccessCreationResponse>, (StatusCode, String)>{
    
    // Get the current engine form the app state
    let mut engine = state.engine.write().unwrap();

    // get the collection by name
    let collection = engine.get_collection_mut(&payload.collection_name)
        .map_err(|e| (StatusCode::NOT_FOUND, e.to_string()))?;

    // get the max layer and metadata from the request
    let max_layer = payload.max_layer.unwrap_or(0);
    let metadata = payload.metadata.unwrap_or_default();

    // insert the record into the collection
    collection.insert(payload.embeddings, max_layer, Some(metadata))
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?; 
    Ok(Json(DefaultSuccessCreationResponse {
        success: true,
        message: format!("Record inserted successfully"),
    }))
}

pub async fn query_vector_handler(
    State(state): State<AppState>, 
    Json(payload): Json<CollectionQueryRequest>
) -> Result<Json<CollectionQueryResponse>, (StatusCode, String)> {
    let engine = state.engine.read().unwrap();
    let collection = engine.get_collection(&payload.collection_name)
        .map_err(|e| (StatusCode::NOT_FOUND, e.to_string()))?;
    
    let res_option = collection.query(payload.vector)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, format!("Query error: {:?}", e)))?;

    if let Some((id, distance)) = res_option {
        let record = collection.get(&id)
            .map(|r| r.clone())
            .map_err(|e| (StatusCode::NOT_FOUND, format!("Record not found: {:?}", e)))?;

        Ok(Json(CollectionQueryResponse {
            id,
            distance,
            record: Some(record),
        }))
    } else {
        Err((StatusCode::NOT_FOUND, "No matching vector found".to_string()))
    }
}
