use std::collections::HashMap;

use crate::domain::entities::Record;
use serde::{Serialize, Deserialize};


#[derive(Serialize, Deserialize)]
pub struct CreateEngineRequest {
    pub id: String,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct DefaultSuccessCreationResponse{
    pub success: bool,
    pub message: String,
}

#[derive(Serialize, Deserialize)]
pub struct CreateCollectionRequest {
    pub collection_name: String,
    pub index_type: Option<String>,
}

#[derive(Serialize, Deserialize)]
pub struct DeleteCollectionRequest {
    pub collection_name: String,
}

#[derive(Serialize, Deserialize)]
pub struct GetCollectionRequest {
    pub collection_name: String,
}

#[derive(Serialize, Deserialize)]
pub struct UpdateCollectionRequest {
    pub collection_name: String,
    pub record: Record,
}

#[derive(Serialize, Deserialize)]
pub struct InsertRecordRequest{
    pub collection_name: String,
    pub embeddings: Vec<f32>, 
    pub max_layer: Option<usize>, 
    pub metadata: Option<HashMap<String, String>>
}

#[derive(Serialize, Deserialize)]
pub struct CollectionQueryRequest {
    pub collection_name: String,
    pub vector: Vec<f32>,
}

#[derive(Serialize, Deserialize)]
pub struct CollectionQueryResponse {
    pub id: String,
    pub distance: f32,
    pub record: Option<Record>,
}