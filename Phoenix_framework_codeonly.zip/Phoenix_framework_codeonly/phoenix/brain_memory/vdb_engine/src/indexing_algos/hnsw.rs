use crate::domain::entities::{Collection, DistanceMetric, Record, RecordError};
use crate::indexing_algos::indexing::Indexing; 
use rand::Rng;
use std::collections::BinaryHeap;
use rustc_hash::FxHashSet;
use std::cmp::{Reverse, Ordering};
use std::cell::RefCell;
use rayon::prelude::*;

const M: usize = 16;
const M_MAX_0: usize = 32;
const EF_CONSTRUCTION: usize = 100;
const EF_SEARCH: usize = 50;

#[derive(Clone, Copy, Debug)]
struct OrderedFloat(f32);
impl PartialEq for OrderedFloat {
    fn eq(&self, other: &Self) -> bool {
        self.0 == other.0
    }
}
impl Eq for OrderedFloat {}
impl PartialOrd for OrderedFloat {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.0.partial_cmp(&other.0)
    }
}
impl Ord for OrderedFloat {
    fn cmp(&self, other: &Self) -> Ordering {
        self.partial_cmp(other).unwrap_or(Ordering::Equal)
    }
}

pub struct SearchContext {
    pub visited: FxHashSet<usize>,
    pub candidates: BinaryHeap<Reverse<(OrderedFloat, usize)>>,
    pub results: BinaryHeap<(OrderedFloat, usize)>,
}

impl SearchContext {
    pub fn new() -> Self {
        Self {
            visited: FxHashSet::default(),
            candidates: BinaryHeap::new(),
            results: BinaryHeap::new(),
        }
    }
    
    pub fn clear(&mut self) {
        self.visited.clear();
        self.candidates.clear();
        self.results.clear();
    }
}

thread_local! {
    static SEARCH_CTX: RefCell<SearchContext> = RefCell::new(SearchContext::new());
}

pub struct HnswIndex<M: DistanceMetric> {
    _marker: std::marker::PhantomData<M>,
}

// 1. Struct-specific methods (Internal helpers)
impl<M: DistanceMetric> HnswIndex<M> {
    fn search_layer(
        collection: &Collection,
        query: &[f32],
        entry_points: &[usize],
        layer: usize,
        ef: usize,
        ctx: &mut SearchContext,
    ) {
        ctx.clear();

        for &ep in entry_points {
            ctx.visited.insert(ep);
            let dist = M::calculate(&collection.vectors[ep].embeddings, query);
            ctx.candidates.push(Reverse((OrderedFloat(dist), ep)));
            ctx.results.push((OrderedFloat(dist), ep));
        }

        while let Some(Reverse((c_dist, c_id))) = ctx.candidates.pop() {
            let f_dist = ctx.results.peek().unwrap().0;

            if c_dist > f_dist {
                break;
            }

            let curr_node = &collection.vectors[c_id];
            if layer >= curr_node.layers.len() {
                continue;
            }

            for &neighbor_id in &*curr_node.layers[layer].read() {
                if ctx.visited.insert(neighbor_id) {
                    let neighbor = &collection.vectors[neighbor_id];
                    let dist = M::calculate(&neighbor.embeddings, query);
                    let f_dist = ctx.results.peek().unwrap().0;
                    
                    if ctx.results.len() < ef || dist < f_dist.0 {
                        ctx.candidates.push(Reverse((OrderedFloat(dist), neighbor_id)));
                        ctx.results.push((OrderedFloat(dist), neighbor_id));
                        if ctx.results.len() > ef {
                            ctx.results.pop();
                        }
                    }
                }
            }
        }
    }

    fn random_layer() -> usize {
        let mut rng = rand::thread_rng();
        let r: f32 = rng.gen_range(0.00001..1.0);
        let m_l = 1.0 / (M as f32).ln();
        (-r.ln() * m_l).floor() as usize
    }
}

// 2. Trait Implementation (The Public API)
impl<M: DistanceMetric> Indexing for HnswIndex<M> {
    fn search(collection: &Collection, query: &[f32]) -> Result<Option<(String, f32)>, RecordError> {
        let mut current_node_id = match &collection.entry_point {
            Some(id) => *id,
            None => return Err(RecordError::RecordNotFound("No entry point found, the collection is empty.".to_string())),
        };

        // Phase 1: Greedily find entry point for layer 0
        let mut current_layer = collection.max_layer;
        while current_layer > 0 {
            let mut changed = true;
            while changed {
                changed = false;
                let curr_node = &collection.vectors[current_node_id];
                let mut best_dist = M::calculate(&curr_node.embeddings, query);
                
                if current_layer < curr_node.layers.len() {
                    for &neighbor_id in &*curr_node.layers[current_layer].read() {
                        let neighbor = &collection.vectors[neighbor_id];
                        let dist = M::calculate(&neighbor.embeddings, query);
                        if dist < best_dist {
                            best_dist = dist;
                            current_node_id = neighbor_id;
                            changed = true;
                        }
                    }
                }
            }
            current_layer -= 1;
        }

        // Phase 2: Beam search on layer 0
        SEARCH_CTX.with(|ctx_cell| {
            let mut ctx = ctx_cell.borrow_mut();
            Self::search_layer(collection, query, &[current_node_id], 0, EF_SEARCH, &mut ctx);
            let closest = ctx.results.drain().min_by(|a, b| a.0.cmp(&b.0));
            
            match closest {
                Some((dist, id)) => Ok(Some((collection.vectors[id].id.clone(), dist.0))),
                None => Ok(None)
            }
        })
    }

    fn insert(collection: &mut Collection, mut record: Record) {
        let node_max_layer = Self::random_layer();

        // Expand the layers array if node_max_layer > original max_layer
        if record.layers.len() <= node_max_layer {
            record.layers.resize_with(node_max_layer + 1, || parking_lot::RwLock::new(Vec::new()));
        }
        
        record.mapped_id = collection.next_id;
        collection.id_map.insert(record.id.clone(), record.mapped_id);
        collection.next_id += 1;

        if collection.entry_point.is_none() {
            collection.entry_point = Some(record.mapped_id);
            collection.max_layer = node_max_layer;
            collection.vectors.push(record);
            return;
        }

        let mut current_node_id = collection.entry_point.unwrap();
        let mut current_layer = collection.max_layer;

        // Phase 1: Greedily search from max_layer down to node_max_layer + 1
        while current_layer > node_max_layer {
            let mut changed = true;
            while changed {
                changed = false;
                let curr_node = &collection.vectors[current_node_id];
                let mut best_dist = M::calculate(&curr_node.embeddings, &record.embeddings);
                
                if current_layer < curr_node.layers.len() {
                    for &neighbor_id in &*curr_node.layers[current_layer].read() {
                        let neighbor = &collection.vectors[neighbor_id];
                        let dist = M::calculate(&neighbor.embeddings, &record.embeddings);
                        if dist < best_dist {
                            best_dist = dist;
                            current_node_id = neighbor_id;
                            changed = true;
                        }
                    }
                }
            }
            if current_layer == 0 { break; }
            current_layer -= 1;
        }

        let new_id = record.mapped_id;
        collection.vectors.push(record);
        
        // Phase 2: Beam search and link for layer <= node_max_layer
        let mut ep = vec![current_node_id];
        let max_layer_to_link = std::cmp::min(collection.max_layer, node_max_layer);

        SEARCH_CTX.with(|ctx_cell| {
            let mut ctx = ctx_cell.borrow_mut();
            
            for layer in (0..=max_layer_to_link).rev() {
                Self::search_layer(collection, &collection.vectors[new_id].embeddings, &ep, layer, EF_CONSTRUCTION, &mut ctx);
                
                let m_max = if layer == 0 { M_MAX_0 } else { M };
                
                let mut neighbors: Vec<(OrderedFloat, usize)> = ctx.results.drain().collect();
                // Sort by distance (closest first)
                neighbors.sort_by(|a, b| a.0.cmp(&b.0));
                
                // Entry points for next layer down should be the full candidate set found here
                ep = neighbors.iter().map(|&(_, id)| id).collect();

                // Link up to M neighbors
                neighbors.truncate(M);
                let neighbor_ids: Vec<usize> = neighbors.into_iter().map(|(_, id)| id).collect();

                collection.vectors[new_id].layers[layer] = parking_lot::RwLock::new(neighbor_ids.clone());
                
                // Add reverse links and mark nodes that need shrinking
                let mut shrink_tasks = vec![];
                for &n_id in &neighbor_ids {
                    let mut n_layer = collection.vectors[n_id].layers[layer].write();
                    n_layer.push(new_id);
                    if n_layer.len() > m_max {
                        shrink_tasks.push(n_id);
                    }
                }

                // Shrink the overflowed neighbors
                for n_id in shrink_tasks {
                    let n_emb = collection.vectors[n_id].embeddings.clone();
                    let mut connections: Vec<(OrderedFloat, usize)> = collection.vectors[n_id].layers[layer]
                        .read()
                        .iter()
                        .map(|&id| {
                            let dist = M::calculate(&collection.vectors[id].embeddings, &n_emb);
                            (OrderedFloat(dist), id)
                        })
                        .collect();
                    connections.sort(); // ascending distance
                    connections.truncate(m_max);
                    *collection.vectors[n_id].layers[layer].write() = connections.into_iter().map(|(_, id)| id).collect();
                }
            }
        });

        if node_max_layer > collection.max_layer {
            collection.max_layer = node_max_layer;
            collection.entry_point = Some(new_id);
        }
    }

    fn insert_batch(collection: &mut Collection, mut records: Vec<Record>) {
        if records.is_empty() { return; }

        let mut new_nodes = Vec::with_capacity(records.len());
        let mut max_layer_in_batch = 0;
        let mut best_entry_point = 0;

        for mut record in records {
            let node_max_layer = Self::random_layer();
            if record.layers.len() <= node_max_layer {
                record.layers.resize_with(node_max_layer + 1, || parking_lot::RwLock::new(Vec::new()));
            }
            record.mapped_id = collection.next_id;
            collection.id_map.insert(record.id.clone(), record.mapped_id);
            collection.next_id += 1;
            
            if node_max_layer > max_layer_in_batch {
                max_layer_in_batch = node_max_layer;
                best_entry_point = record.mapped_id;
            }

            new_nodes.push((record.mapped_id, node_max_layer));
            collection.vectors.push(record);
        }

        if collection.entry_point.is_none() {
            collection.entry_point = Some(new_nodes[0].0);
            collection.max_layer = new_nodes[0].1;
        }

        let collection_ref = &*collection; // Immutable reference for Rayon
        let current_ep = collection_ref.entry_point.unwrap();
        let current_max_layer = collection_ref.max_layer;

        new_nodes.par_iter().for_each(|&(new_id, node_max_layer)| {
            if new_id == current_ep { return; } // Skip the first entry point if it was just created

            let mut current_node_id = current_ep;
            let mut current_layer = current_max_layer;

            // Phase 1: Greedily search from max_layer down to node_max_layer + 1
            while current_layer > node_max_layer {
                let mut changed = true;
                while changed {
                    changed = false;
                    let curr_node = &collection_ref.vectors[current_node_id];
                    let mut best_dist = M::calculate(&curr_node.embeddings, &collection_ref.vectors[new_id].embeddings);
                    
                    if current_layer < curr_node.layers.len() {
                        for &neighbor_id in &*curr_node.layers[current_layer].read() {
                            let neighbor = &collection_ref.vectors[neighbor_id];
                            let dist = M::calculate(&neighbor.embeddings, &collection_ref.vectors[new_id].embeddings);
                            if dist < best_dist {
                                best_dist = dist;
                                current_node_id = neighbor_id;
                                changed = true;
                            }
                        }
                    }
                }
                if current_layer == 0 { break; }
                current_layer -= 1;
            }

            let mut ep = vec![current_node_id];
            let max_layer_to_link = std::cmp::min(current_max_layer, node_max_layer);

            SEARCH_CTX.with(|ctx_cell| {
                let mut ctx = ctx_cell.borrow_mut();
                for layer in (0..=max_layer_to_link).rev() {
                    Self::search_layer(collection_ref, &collection_ref.vectors[new_id].embeddings, &ep, layer, EF_CONSTRUCTION, &mut ctx);
                    let m_max = if layer == 0 { M_MAX_0 } else { M };
                    
                    let mut neighbors: Vec<(OrderedFloat, usize)> = ctx.results.drain().collect();
                    neighbors.sort_by(|a, b| a.0.cmp(&b.0));
                    ep = neighbors.iter().map(|&(_, id)| id).collect();
                    neighbors.truncate(M);
                    let neighbor_ids: Vec<usize> = neighbors.into_iter().map(|(_, id)| id).collect();

                    *collection_ref.vectors[new_id].layers[layer].write() = neighbor_ids.clone();
                    
                    let mut shrink_tasks = vec![];
                    for &n_id in &neighbor_ids {
                        let mut n_layer = collection_ref.vectors[n_id].layers[layer].write();
                        n_layer.push(new_id);
                        if n_layer.len() > m_max {
                            shrink_tasks.push(n_id);
                        }
                    }

                    for n_id in shrink_tasks {
                        let n_emb = collection_ref.vectors[n_id].embeddings.clone();
                        let mut connections: Vec<(OrderedFloat, usize)> = collection_ref.vectors[n_id].layers[layer]
                            .read()
                            .iter()
                            .map(|&id| {
                                let dist = M::calculate(&collection_ref.vectors[id].embeddings, &n_emb);
                                (OrderedFloat(dist), id)
                            })
                            .collect();
                        connections.sort(); 
                        connections.truncate(m_max);
                        *collection_ref.vectors[n_id].layers[layer].write() = connections.into_iter().map(|(_, id)| id).collect();
                    }
                }
            });
        });

        // Promote the highest node in the batch to entry point if it exceeds the current global max_layer
        if max_layer_in_batch > collection.max_layer {
            collection.max_layer = max_layer_in_batch;
            collection.entry_point = Some(best_entry_point);
        }
    }
}