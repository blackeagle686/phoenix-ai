# Task 02: Persistence & Serialization

## Context
Right now, our Vector DB is blazing fast because everything lives in memory (`HashMap` and `Vec`). However, it has one fatal flaw: if the process stops, we lose all our vectors. 

As a Senior Engineer, your next task is to design the storage persistence layer. We need to take our in-memory `Engine` struct and write its exact state out to the disk, and be able to read it back into memory on startup.

## Objectives

### 1. Add Serialization Dependencies
- Add the `serde` crate (with the `derive` feature) to your `Cargo.toml`.
- Add `bincode`. (JSON is great for reading, but for a vector database with millions of `f32` numbers, we need a compact, high-speed binary format. `bincode` is the Rust standard for this).

### 2. Derive Traits
- Update `Record`, `Collection`, and `Engine` to derive `Serialize` and `Deserialize`.
- *Hint:* You might run into issues if you have fields that don't easily serialize, though currently, your structs look very clean.

### 3. Disk I/O Methods
- Add two new methods to your `EngineTrait` (and implement them in `in_memory.rs`):
  ```rust
  // Serializes the entire engine and writes it to a file
  fn save_to_disk(&self, file_path: &str) -> Result<(), EngineError>;
  
  // Reads the file, deserializes the bytes, and returns a fully populated Engine
  fn load_from_disk(file_path: &str) -> Result<Self, EngineError> where Self: Sized;
  ```

### 4. Error Handling Integration
- Writing to disk introduces a whole new class of errors (e.g., File Not Found, Permission Denied, Corrupted Data). 
- Update `EngineError` in `entities.rs` to handle `std::io::Error` and the serialization errors from `bincode`.
- *Senior Tip:* Look into the `#[from]` attribute in `thiserror` to automatically wrap `std::io::Error`.

## Definition of Done (DoD)
- [ ] `Cargo.toml` has `serde` and `bincode`.
- [ ] `Engine::save_to_disk` successfully writes a binary file to the `/tmp/` folder or local directory.
- [ ] `Engine::load_from_disk` successfully restores the database state and HNSW index connections.
- [ ] You have a test in `src/main.rs` that inserts a vector, saves to disk, destroys the engine, and then loads it back from disk and successfully searches for it.

**Deliverable:** Implement the persistence logic and hit me up for a review. We're about to make this DB truly durable!
