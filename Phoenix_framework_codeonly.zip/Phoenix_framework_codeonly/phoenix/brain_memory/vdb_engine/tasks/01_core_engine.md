# Task 01: Core Engine & Memory Layout

## Context
As a Senior Engineer, you know that a vector database lives and dies by its memory layout and calculation speed. Brute-force scanning (Phase 1) is slow, but we can make it blisteringly fast if we optimize cache locality and ensure our distance calculations are auto-vectorized by the compiler (SIMD).

## Objectives
Design and implement the foundational in-memory data structures and distance metrics for the engine. 

### 1. Memory & Type Design
- Define a `Vector` representation that prioritizes cache-locality. (Consider how `f32` arrays are stored).
- Define a `Record` that associates a unique ID (e.g., UUID or `u64`) and optional metadata (payload) with a `Vector`.
- **Constraint:** Ensure your memory layout minimizes pointer indirection. `Vec<Box<[f32]>>` is terrible for cache; consider flattened arrays or `Vec<f32>` chunks if possible, or standard `Vec<f32>` but justify your choice.

### 2. Distance Metric Traits (Static Dispatch)
- We need to support Multiple Distance Metrics (Euclidean, Cosine, Dot Product).
- **Constraint:** Do not use dynamic dispatch (`Box<dyn DistanceMetric>`) in the hot loop. Design a trait (e.g., `DistanceCalculator`) and use generics/static dispatch so the compiler can inline the math operations.
- Implement Euclidean and Cosine similarity. 
- *Bonus:* Structure the loops so LLVM can easily auto-vectorize them (SIMD).

### 3. The `Collection` Abstraction
- Design a `Collection` struct that holds the vectors and provides a CRUD interface (`insert`, `get`, `delete`).
- Implement the `search` method: Given a query vector and $K$, return the Top $K$ closest records.
- **Constraint:** Do not sort the entire array for the search! Use a `BinaryHeap` (Min/Max Heap) to maintain the top $K$ results in $O(N \log K)$ time instead of $O(N \log N)$.

### 4. Error Handling
- Define a custom `crate::error::Error` enum using `thiserror` (or manually implementing `std::error::Error`). Avoid panicking (`unwrap`/`expect`) in library code.

## Definition of Done (DoD)
- [ ] `src/core/mod.rs` (or similar structure) contains the types and traits.
- [ ] Unit tests validate the exact math for Cosine and Euclidean distances against known vectors.
- [ ] `criterion` benchmarks are set up to measure the throughput of `Collection::search` on 10,000 vectors.
- [ ] Code passes `cargo clippy --all-targets --all-features -- -D warnings`.

**Deliverable:** Implement the above and submit it for a code review (PR style). Let's discuss your memory layout choices before you get too deep into the `Collection` search logic.
