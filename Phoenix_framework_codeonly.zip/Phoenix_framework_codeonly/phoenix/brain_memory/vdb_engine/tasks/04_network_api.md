# Task 04: The Network API & Concurrency (Final Boss)

## Context
Right now, your Vector DB is an incredibly fast, highly optimized library. But databases aren't libraries; they are servers. We need to expose your engine to the outside world so that Python, Node.js, and other applications can insert data and search for nearest neighbors over HTTP.

Because web servers handle multiple requests at the exact same time, we have to deal with **Concurrency**. You can't have two HTTP requests trying to mutably insert into the HNSW graph at the exact same millisecond—Rust will stop you!

## Objectives

### 1. Dependencies
Add the following to your `Cargo.toml`:
- `tokio = { version = "1.0", features = ["full"] }` (The async runtime)
- `axum = "0.7"` (The lightning-fast HTTP framework)
- `serde_json = "1.0"` (To parse JSON requests/responses)

### 2. Thread-Safe State
In `src/main.rs`, initialize your `Engine`. Then, wrap it in a thread-safe concurrent pointer:
```rust
use std::sync::{Arc, RwLock};
let engine = Engine::new("production");
let shared_state = Arc::new(RwLock::new(engine));
```
*Note: `RwLock` allows multiple readers (`search`) at the same time, but only one writer (`insert`). This is perfect for a Vector DB!*

### 3. The HTTP Endpoints (Axum)
Build an Axum router that injects `shared_state` into the following endpoints:
1. **`POST /collection/create`** - Takes a JSON payload with a `name` and creates a collection.
2. **`POST /insert`** - Takes JSON containing a `collection_name`, `id` (String), and `embeddings` (Vec<f32>).
3. **`POST /search`** - Takes JSON with a `collection_name`, `query` (Vec<f32>), and returns the closest `id` and its distance.

### 4. Wire It Up
Make your `fn main()` into an `async fn main()`, bind a TCP listener to `0.0.0.0:3000`, and start the Axum server!

## Definition of Done (DoD)
- [ ] `main.rs` starts a web server on port 3000.
- [ ] You can hit `/insert` using `curl` or Postman to add a vector.
- [ ] You can hit `/search` using `curl` or Postman and get the nearest neighbor back!
- [ ] Multiple requests can happen simultaneously safely because of `Arc<RwLock>`.

**Deliverable:** Build the API, test it with `curl`, and push it up. Once you finish this, you have officially built a production-style Vector Database from scratch. Go crush the gym, and tackle this when you get back (or bang it out now if you're feeling explosive)!
