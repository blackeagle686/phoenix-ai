# Task 03: Performance Optimization & Memory Layout

## Context
You have successfully implemented an in-memory HNSW vector database and given it disk persistence. Structurally, the database is sound. However, we have a massive bottleneck sitting right in our hot path that will crush our performance at scale: **Heap Allocations for Graph Traversal**.

Currently, our HNSW layers look like this:
```rust
pub layers: Vec<Vec<String>>
```
During a search, the algorithm hops from node to node. Every hop currently requires cloning or hashing a `String`. In a graph with 1,000,000 vectors, looking up neighbors via `String` keys in a `HashMap` will completely destroy our CPU Cache hit rate. 

We need to transition from `String` keys to raw, cache-friendly integers (like `usize` or `u64`).

## Objectives

### 1. The ID Mapper (String -> usize)
- The external user still wants to use `String` IDs (like "user_123" or "doc_456").
- Create an internal mapping system. When a vector is inserted, assign it an internal sequential `usize` (e.g., 0, 1, 2, 3...).
- Maintain a `HashMap<String, usize>` to map user IDs to internal IDs.
- *Bonus:* Keep a `Vec<String>` to map internal IDs back to user IDs (since internal IDs are sequential, index `0` of the Vec holds the String for internal ID `0`).

### 2. Contiguous Memory Layout
- Change `Collection::vectors` from a `HashMap<String, Record>` to a flat array/vector: `Vec<Record>`. 
- Since our internal IDs are now sequential `usize` (0, 1, 2...), we can instantly access any record by just doing `collection.vectors[internal_id]`. This is $O(1)$ and avoids the hashing overhead of `HashMap`.

### 3. Update the HNSW Graph
- Update `Record`: `pub layers: Vec<Vec<usize>>`
- The entire HNSW algorithm should now traverse via `usize` indices instead of Strings. This will make graph traversal nearly instantaneous as the CPU can prefetch the contiguous memory.

### 4. Benchmarking
- Add `criterion` to your `Cargo.toml` as a `[dev-dependencies]`.
- Write a benchmark that inserts 10,000 random vectors and queries 100 of them. We want to measure the exact latency in microseconds.

## Definition of Done (DoD)
- [ ] Internal graph routing uses `usize` instead of `String`.
- [ ] `Collection` uses a `Vec<Record>` instead of `HashMap<String, Record>`.
- [ ] `insert` and `search` APIs still accept/return `String` IDs for the user.
- [ ] All tests and `cargo check` pass.

**Deliverable:** Implement the integer-based ID mapping and let's see how much faster our engine gets!
