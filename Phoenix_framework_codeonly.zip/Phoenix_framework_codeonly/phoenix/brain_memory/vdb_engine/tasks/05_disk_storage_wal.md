# 05: Disk Storage & WAL (Write-Ahead Logging) Implementation Plan

## Overview
Currently, the database relies on in-memory operations and serializes the entire state to disk via `bincode`. For a production-grade system, this is a bottleneck. We need a robust Disk Storage Engine and a Write-Ahead Log (WAL) for durability (crash-recovery) and large-scale persistence (exceeding RAM capacity).

As your Senior Staff Engineering Manager, I have broken down the architecture into functional phases. Your goal is to execute these modules with high-performance Rust principles.

---

## Phase 1: Architecture & Data Formats (Deadline: Day 1-2)
**Goal:** Define the exact binary layouts for your files. Don't write logic yet; write structs and `[repr(C)]` layouts.

### Tasks:
- [ ] **Define WAL Record Layout:**
  - Header: CRC32 (4 bytes), Timestamp (8 bytes), Opcode (1 byte: Insert/Update/Delete).
  - Body: Key length (4 bytes), Key (String/UUID), Vector length (4 bytes), Vector data (f32 array).
- [ ] **Define Segment / SSTable Format:**
  - Data Blocks: Packed vectors and metadata.
  - Index Block: File offsets for keys to avoid scanning.
  - Bloom Filter: Fast probabilistic key existence checks.
- [ ] **Manager Check-in:** Present the Structs and serialization logic (using `byteorder` or raw byte manipulation instead of just `bincode` for fine-grained control).

---

## Phase 2: Write-Ahead Log (WAL) Implementation (Deadline: Day 3-5)
**Goal:** Guarantee durability. Every write MUST be appended to the WAL before updating the in-memory index.

### Tasks:
- [ ] **Create `src/storage/wal.rs`:**
  - Implement a `WalWriter` that opens a file in `O_APPEND` mode.
  - Implement buffered writes with explicit `.sync_data()` or `.sync_all()` (`fsync`) policies.
- [ ] **Implement Crash Recovery (`WalReader`):**
  - Implement logic to read the WAL sequentially on startup.
  - If a checksum fails, cleanly truncate the corrupted tail (handle partial writes/crashes).
- [ ] **Implement Log Rotation:**
  - When `wal_001.log` reaches a threshold (e.g., 64MB), roll over to `wal_002.log`.
- [ ] **Manager Check-in:** Demonstrate a crash test. Insert 1000 records, SIGKILL the process, and show successful recovery from the WAL.

---

## Phase 3: Segment / Immutable Disk Storage (Deadline: Day 6-9)
**Goal:** When memory (MemTable) is full, flush it to an immutable Segment file on disk.

### Tasks:
- [ ] **Implement MemTable Flush (`src/storage/segment.rs`):**
  - Convert the current in-memory structure into a flushed disk file.
  - Write records sequentially.
- [ ] **Memory-Mapped Reads:**
  - Use the `memmap2` crate to map the Segment files into virtual memory.
  - Implement a query path that reads vectors directly from the mmap'ed region without loading the whole file into RAM.
- [ ] **Manager Check-in:** Demonstrate querying a 5GB vector dataset on a machine with 1GB RAM without OOM errors.

---

## Phase 4: Page Cache & Buffer Pool (Deadline: Day 10-12)
**Goal:** Don't rely solely on the OS page cache; control your memory.

### Tasks:
- [ ] **Implement LRU Cache:**
  - Create a fixed-size Buffer Pool that caches frequently accessed disk blocks (or vectors).
  - Use thread-safe structures (`moka` or custom `RwLock` + `HashMap` + Linked List).
- [ ] **Manager Check-in:** Run benchmarks showing read latency improvements for "hot" vectors vs "cold" vectors.

---

## Phase 5: Compaction (LSM-Tree Style) (Deadline: Day 13-14)
**Goal:** Clean up the mess. Merging small files into large ones and removing deleted data.

### Tasks:
- [ ] **Background Compaction Thread:**
  - Spawn a background worker that monitors Segment files.
  - Merge multiple small segments into a larger segment.
  - Discard records that are marked as deleted (Tombstones).
- [ ] **Manager Check-in:** Show disk space reclaiming after updating/deleting 10,000 vectors and running compaction.

---

## Your First Step:
Create a new module `src/storage/mod.rs` and `src/storage/wal.rs`. Start defining the `WalRecord` struct for **Phase 1**. 

Ping me when you have the basic structs mapped out or if you want to debate the design. I'll review your code and we will iterate.
