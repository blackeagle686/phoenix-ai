# Vector Database Engine Architecture & Plan

Welcome to the team! Building a Vector Database from scratch is one of the best ways to deeply understand both **Rust** (memory management, concurrency, traits, serialization) and **Systems Design** (storage, indexing algorithms, networking).

## Core Concepts
A Vector Database stores mathematical representations of data (vectors/embeddings) and allows for fast retrieval of "similar" items using distance metrics like Cosine Similarity or Euclidean Distance.

---

## 🗺️ Implementation Phases

### Phase 1: The Core Engine (In-Memory)
*Goal: Understand Rust basics, ownership, and basic math operations.*
1. **Define the Types**: Create the core `Vector` struct (wrapping an array/vec of `f32`) and a `Record` struct (adding metadata/IDs).
2. **Distance Metrics**: Implement traits for distance calculation (Euclidean, Cosine, Dot Product).
3. **In-Memory Store**: Create a `Collection` struct that holds vectors in a standard Rust `Vec`.
4. **Brute-force Search**: Implement exact K-Nearest Neighbors (KNN) search by scanning all vectors.

### Phase 2: Persistence & Storage
*Goal: Understand Rust file I/O, serialization, and working with disks.*
1. **Serialization**: Use `serde` and a fast binary format (like `bincode`) to convert vectors to bytes.
2. **Disk Storage**: Write the collection to a file so data persists across restarts.
3. **Write-Ahead Log (WAL)**: (Advanced) Ensure data isn't lost if the engine crashes during a write.

### Phase 3: Indexing for Speed
*Goal: Understand data structures and algorithmic complexity.*
1. **The Problem**: Brute-force is $O(N)$. We need sub-linear search.
2. **Inverted File Index (IVF)** or **LSH (Locality Sensitive Hashing)**: Implement a basic partitioning algorithm to narrow down the search space.
3. **HNSW (Hierarchical Navigable Small World)**: (Optional/Advanced) The industry standard for vector search.

### Phase 4: Network API & Concurrency
*Goal: Understand Rust async/await, multi-threading, and networking.*
1. **Concurrency**: Use `Arc` and `RwLock` to allow multiple threads to read/write the collection safely.
2. **HTTP/gRPC API**: Wrap the engine in a network layer (using `Axum` or `Tonic`) so clients can send HTTP requests to insert and query vectors.

---

## 🛠️ Phase 1 Tasks (Current)

- [ ] **Task 1.1**: Define the basic `Vector` and `Record` structs in `src/lib.rs`.
- [ ] **Task 1.2**: Implement Euclidean Distance calculation.
- [ ] **Task 1.3**: Write unit tests to prove the math is correct.
