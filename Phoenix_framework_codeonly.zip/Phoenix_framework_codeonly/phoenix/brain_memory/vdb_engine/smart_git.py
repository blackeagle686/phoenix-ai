import os
import time
import subprocess
from datetime import datetime

# Configuration
INTERVAL = 10 # Seconds

def run_command(command):
    """Runs a shell command and returns stdout."""
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=True,
            encoding="utf-8",
            errors="replace",
        )
        return (result.stdout or "").strip()
    except Exception as e:
        stderr = getattr(e, "stderr", str(e))
        print(f"Error running command {' '.join(command)}: {stderr}")
        return ""


def run_command_ok(command):
    """Runs a shell command and returns True on success."""
    try:
        subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=True,
            encoding="utf-8",
            errors="replace",
        )
        return True
    except Exception as e:
        stderr = getattr(e, "stderr", str(e))
        print(f"Error: {e}")
        print(f"Error running command {' '.join(command)}: {stderr}")
        return False


def get_current_branch():
    return run_command(["git", "rev-parse", "--abbrev-ref", "HEAD"])

def get_status_porcelain():
    return run_command(["git", "status", "--porcelain=v1"])

def has_changes(status_text):
    return bool(status_text.strip())

def stage_all():
    return run_command_ok(["git", "add", "."])

def get_detailed_changes():
    """Parses 'git diff --cached' to extract class/function names from hunk headers."""
    diff = run_command(["git", "diff", "--cached"])
    
    current_file = None
    changes = {}
    
    for line in diff.splitlines():
        if line.startswith("diff --git "):
            parts = line.split()
            if len(parts) >= 4:
                current_file = os.path.basename(parts[3][2:]) # remove b/
                if current_file not in changes:
                    changes[current_file] = set()
        elif line.startswith("@@ ") and current_file:
            parts = line.split(" @@ ", 1)
            if len(parts) > 1:
                context = parts[1].strip()
                if context:
                    # Clean up to extract just the class/func name roughly
                    context = context.split('(')[0].split('{')[0].strip()
                    # Filter out useless context (imports, long strings)
                    if context and len(context) < 40 and not context.startswith("import ") and not context.startswith("use "):
                        changes[current_file].add(context)
                        
    return changes

def generate_deterministic_commit():
    """
    Parses 'git diff --cached --name-status' and detailed hunk headers 
    to generate a commit message like: 
    "Update [file.py (def my_func, class MyClass)]"
    """
    names = run_command(["git", "diff", "--cached", "--name-status"])
    detailed = get_detailed_changes()
    
    added = []
    updated = []
    deleted = []
    
    for line in names.splitlines():
        if not line.strip(): 
            continue
        parts = line.split(maxsplit=1)
        if len(parts) < 2: 
            continue
            
        status, file_path = parts
        file_name = os.path.basename(file_path)
        
        # Attach the class/function context to the file name!
        file_str = file_name
        if file_name in detailed and detailed[file_name]:
            contexts = list(detailed[file_name])[:2] # grab up to 2 contexts to keep it short
            file_str += f" ({', '.join(contexts)})"
        
        # Git status letters: A (Added), M (Modified), D (Deleted), R (Renamed)
        if status.startswith('A') or status.startswith('R'):
            added.append(file_str)
        elif status.startswith('D'):
            deleted.append(file_str)
        elif status.startswith('M'):
            updated.append(file_str)
            
    msgs = []
    if added: 
        msgs.append(f"Add [{', '.join(added)}]")
    if updated: 
        msgs.append(f"Update [{', '.join(updated)}]")
    if deleted: 
        msgs.append(f"Delete [{', '.join(deleted)}]")
    
    if not msgs:
        return f"Auto-commit: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
    # Cap string length so commit messages aren't infinitely long
    final_message = " | ".join(msgs)
    if len(final_message) > 150:
        final_message = final_message[:147] + "..."
        
    return final_message

def commit_with_message(message):
    return run_command_ok(["git", "commit", "-m", message])

def smart_sync():
    print(f"[*] Checking for changes at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}...")

    status = get_status_porcelain()
    if not has_changes(status):
        print("[ ] No changes detected.")
        return

    print("[+] Changes detected. Staging files...")
    if not stage_all():
        print("[!] Staging failed. Skipping this cycle.")
        return

    print("[*] Generating commit message...")
    message = generate_deterministic_commit()
    print(f"[v] Generated message: {message}")

    print("[*] Committing...")
    if not commit_with_message(message):
        print("[!] Commit failed (or nothing staged). Skipping push.")
        return

    branch = get_current_branch()
    if branch:
        print(f"[*] Pushing to origin {branch}...")
        if run_command_ok(["git", "push", "origin", branch]):
            print("[v] Done.")
        else:
            print("[!] Push failed.")
    else:
        print("[!] Could not determine current branch. Skipping push.")

def main():
    print("=== Deterministic Git Automator Started ===")
    print(f"Interval: {INTERVAL} seconds")
    print(f"Target: {os.getcwd()}")
    
    # Check if this is a git repo
    if not os.path.exists(".git"):
        print("[!] Error: Not a Git repository. Please run in a git project root.")
        return

    try:
        while True:
            smart_sync()
            time.sleep(INTERVAL)
    except KeyboardInterrupt:
        print("\n[!] Stopped by user.")

if __name__ == "__main__":
    main()
